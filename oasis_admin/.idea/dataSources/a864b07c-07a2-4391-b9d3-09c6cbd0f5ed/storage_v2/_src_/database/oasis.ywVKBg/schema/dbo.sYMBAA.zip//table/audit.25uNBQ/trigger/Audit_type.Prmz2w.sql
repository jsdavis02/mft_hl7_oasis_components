CREATE TRIGGER Audit_type ON audit
    AFTER INSERT, UPDATE
    AS

--IF INSERT(audit.type) 
BEGIN
    UPDATE audit
    SET type=ISNULL(audit.type,'notice')

    FROM inserted I INNER JOIN audit
                               ON I.id = audit.id
    WHERE I.type IS NULL;
END
go

